<html>
<head>
</head>
<body>
	<!--include external scripts-->
	<?php 
		require_once("kaltura_client_v3/KalturaClient.php");

		//define constants
		define("KALTURA_PARTNER_ID", ENTER YOUR PARTNER ID);
		define("KALTURA_PARTNER_SERVICE_SECRET", "ENTER YOUR PARTNER ADMIN SECRET");

		//define session variables
		$partnerUserID = '';

		//construct Kaltura objects for session initiation
		$config           = new KalturaConfiguration(KALTURA_PARTNER_ID);
		$client           = new KalturaClient($config);
		$ks               = $client->session->start(KALTURA_PARTNER_SERVICE_SECRET, $partnerUserID, KalturaSessionType::ADMIN);
		$client->setKs($ks);  // set the session in the client
		
		$filter = new KalturaMediaEntryFilter();
		$filter->statusEqual = KalturaEntryStatus::READY;
		$filter->mediaTypeEqual = KalturaMediaType::VIDEO;

		$pager = new KalturaFilterPager();
		$pager->pageSize = 50;
		$pager->pageIndex = 1;

		$list = $client->media->listAction($filter,$pager); // list all of the media items in the partner
		//var_dump($list);
	?>

	<div id="KalturaGallary" style="position:relative;overflow:hidden;">
		<table>
			<?php foreach ($list->objects as $mediaEntry): ?>
				<?php 
					$name     = $mediaEntry->name; // get the entry name
					$id       = $mediaEntry->id;
					$thumbUrl = $mediaEntry->thumbnailUrl;  // get the entry thumbnail URL
					$description = $mediaEntry->description;
				?>
				<td>
					<ul style="list-style:none;">
						<li style="width:120px; height:90px;"><a href="javascript:LoadMedia('<?php echo $id; ?>')">
							<img border="0" src="<?php echo $thumbUrl; ?>" >
						</a></li>
						<li style="width:120px; height:40px;"><?php echo $name; ?></li>
					</ul>
				</td>
			<?php endforeach; ?>
		</table>
	</div>

	<script language="javascript">
	function LoadMedia(entryId) {
		alert (entryId);
		console.log(entryId);
	 }
	</script>

</body>
</html>

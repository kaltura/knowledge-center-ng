<?php
//This sample script shows integration with Kaltura's KRecord widget and Kaltura's Player and API.
//To learn more about KRecord, visit - http://knowledge.kaltura.com/krecord-website-integration-guide
//To learn more about the Kaltura Player visit: http://player.kaltura.com

	require_once('kalturaClient/KalturaClient.php');
	$partnerId = 0000; //Your account partner Id (from KMC>Settings>Integration Settings)
	$config = new KalturaConfiguration($partnerId);
	$config->serviceUrl = 'http://www.kaltura.com/';
	$client = new KalturaClient($config);
	$secret = '00000000000000000000000000000000000'; //your account user secret (from KMC>Settings>Integration Settings)
	$userId = 'your-end-user-id'; //make sure this is configured to be your unique end-user ids, as configured in your user management system
								// Kaltura will create user profiles in realtime for every new user id provided, and assign the video ownership to that user
	$type = KalturaSessionType::USER;
	$playerUiConfId = 19651801; //the uiconf id of your desired player (taken from your KMC > Studio)
	$krecordUiConfId = 16539152; //the uiconf id of your desired krecord widget (if this doesn't work for you, ask your account/project manager for the correct krecord uiconfid)
	$ks = $client->session->start($secret, $userId, $type, $partnerId);
	$client->setKs($ks);
	
	$flashVars = array();
	$flashVars["pid"] = $partnerId;
	$flashVars["ks"] = $ks; 
	$flashVars["isH264"] = true; 
	$flashVars["showUI"] = true; 
	$flashVars["showPreviewTimer"] = true; 
	$flashVars["limitRecord"] = 0; //set this to positive number to indicate seconds to limit recordings to 
	$flashVars["showErrorMessage"] = true; 
	$flashVars["themeURL"] = 'http://cdnbakmi.kaltura.com/p/'.$partnerId.'/sp/0/flash/krecord/v1.6.2/skin.swf'; 
	$flashVars["localeURL"] = 'http://cdnbakmi.kaltura.com/p/'.$partnerId.'/sp/0/flash/krecord/v1.6.2/locale.xml'; 
	$flashVars["host"] = 'www.kaltura.com'; 
	$flashVars["rtmpHost"] = 'rtmp://www.kaltura.com';  
	$flashVars["delegate"] = 'delegate'; 
	$flashVars["entryName"] = "My Test WebCam Recording using Krecord Widget"; 
	$flashVars["entryTags"] = "krecord,test,webcam"; 
	$flashVars["entryDescription"] = "A webcam recording entry created with the KRecrod widget."; 
	$flashVars["debugMode"] = true; 
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Record video using KRecord and playback using player</title>
		<script src="//cdnapisec.kaltura.com/p/<?php echo $partnerId;?>/sp/<?php echo $partnerId;?>00/embedIframeJs/uiconf_id/<?php echo $playerUiConfId;?>/partner_id/<?php echo $partnerId;?>"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js"></script>
		<script language="JavaScript" type="text/javascript">
			$(document).ready(function(){
				$("#statusticker").hide();
			});
			
			var flashObj;
			var uploadedEntryId = null;
			var delegate = {};
			
			delegate.swfReady = function () {
				console.log("KRecord ready for interaction");			 
			}
			
			delegate.previewEnd = function () {
				console.log("preview of recorded content is complete");
			}
			
			delegate.errorMicrophone = function (){
				console.log("errorMicrophone");
			}
			
			delegate.microphoneDenied = function (){
				console.log("microphoneDenied");
			}
			
			delegate.noMicsFound = function (){
				console.log("noMicsFound");
			}
			
			delegate.errorCamera = function (){
				console.log("errorCamera");
			}
			
			delegate.cameraDenied = function (){
				console.log("cameraDenied");
			}
			
			delegate.noCamerasFound = function (){
				console.log("noCamerasFound");
			}
			
			delegate.deviceDetected = function (){
				console.log("deviceDetected");
			}
			
			delegate.netconnectionConnectFailed = function (){
				console.log("netconnectionConnectFailed");
			}
			
			delegate.netconnectionConnectRejected = function () {
				console.log("netconnectionConnectRejected");
			}
			
			delegate.connected = function () {
				console.log("connected");
			}
			
			delegate.connecting = function (){
				console.log("connecting");
			}
			
			delegate.addEntryFailed = function (errorObj){
				console.log(errorObj);
			}
			
			delegate.addEntryComplete = function (addedEntries){
				console.log("New entry added:");
				console.log(addedEntries);
				uploadedEntryId = addedEntries[0].id;
				checkEntryStatus();
			}
		
			
			var kapi = new kWidget.api( { 'wid': '_<?php echo $partnerId; ?>' });
			function checkEntryStatus () {
				$("#krecord").hide();
				$("#statusticker").show();
				kapi.doRequest(
					{  //the request and its parameters:
						'service': 'media', 
						'action': 'get', 
						'entryId': uploadedEntryId,
						'cache_st': Math.floor(Math.random() * 10000)
					}, 
					//the response handler:
					function( data ){
						// get the result from the API response
						var entry = data;
					    // output the data:
					    console.log(entry);
					    if (entry.status == 2) {
					    	embedVideoPlayer();
					    } else {
					    	setTimeout(checkEntryStatus, 5000);
					    }
					}
				);
			}
			
			function embedVideoPlayer () {
				$("#statusticker").hide();
				kWidget.embed({
					  "targetId": "kaltura_player_1378991166",
					  "wid": "_<?php echo $partnerId; ?>",
					  "uiconf_id": <?php echo $playerUiConfId ?>,
					  "flashvars": {
					    "streamerType": "auto",
					    "ks": "<?php echo $ks; ?>"
					  },
					  "entry_id": uploadedEntryId
				});
			}
			
		</script>
	</head>
	<body>
        <div id="krecord" style="width: 400px; height: 300px;"> 
        </div>
        <h1 id="statusticker">Checking entry conversion status, please wait...</h1> 
        <script language="JavaScript" type="text/javascript">
            var params = {
                allowScriptAccess: "always",
                allowNetworking: "all",
                wmode: "window",
                bgcolor: "000000"
           	};
            var attributes  = {
                id: "krecord",
                name: "krecord"
            };
            // set flashVar object
            var flashVars = <?php echo json_encode($flashVars); ?>;
            // embedding the ksu swf
            swfobject.embedSWF("http://www.kaltura.com/krecord/ui_conf_id/<?php echo $krecordUiConfId; ?>/", "krecord", "400","300", "9.0.0", "expressInstall.swf", flashVars, params, attributes);
        </script>
		<div style="clear:both;"></div>
		<div id="kaltura_player_1378991166" style="width: 600px; height: 360px;"></div>
	</body>
</html>
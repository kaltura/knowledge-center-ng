<html>
<head>

<!--include external scripts and define constants -->
<?php 
	require_once("kaltura_client_v3/KalturaClient.php"); 
	
	//define constants
	define("KALTURA_PARTNER_ID", "");
	define("KALTURA_PARTNER_WEB_SERVICE_ADMIN_SECRET", "");

	//define session variables
	$partnerUserID          = '31';

	//Construction of Kaltura objects for session initiation
	$config           = new KalturaConfiguration(KALTURA_PARTNER_ID);
	$client           = new KalturaClient($config);
	$ks               = $client->session->start(KALTURA_PARTNER_WEB_SERVICE_ADMIN_SECRET, $partnerUserID, KalturaSessionType::ADMIN);

	$client->setKs($ks);
	$entryFilter = new KalturaBaseEntryFilter();
	/**
	* Available types:
	* AUTOMATIC = -1;
	* MEDIA_CLIP = 1;
	* MIX = 2;
	* PLAYLIST = 5;
	* DATA = 6;
	* DOCUMENT = 10;
	*/
	if (isset($_GET['entryType']))
		$entryFilter->typeEqual =  (int)$_GET['entryType'];
	$entryFilter->statusEqual = KalturaEntryStatus::READY;
	$entryFilter->orderBy = KalturaBaseEntryOrderBy::CREATED_AT_DESC;
	$kalturaPager = new KalturaFilterPager();
	$kalturaPager->pageSize = 10;
	$kalturaPager->pageIndex = (isset($_GET['p']))? $_GET['p']: 1;
	
	$result = $client->baseEntry->listAction($entryFilter, $kalturaPager);
?>

<!---set style to enable widget overlap -->
<style>
	body { margin: 10px; font-family: Arial; font-size:11px;}
	div.documents { padding:10px; background:#efefef; border:1px solid #666666; width:400px; }
	div.documents div.doc { padding:3px; border:1px solid #ccc; margin:4px; }
	div.documents div.doc span { font-weight:bold; }
</style>

<!---	JavaScript handler methods to react to upload events. -->
<style>object, embed{ position:absolute; top:0; left:0; z-index:999;}</style>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
</head>
<body>
	<h1>List of Entries</h1>
	<p>Available entryType: AUTOMATIC = -1, MEDIA_CLIP = 1, MIX = 2, PLAYLIST = 5, DATA = 6, DOCUMENT = 10</p>
	<div class="documents">
	<?php foreach($result->objects as $entry): ?>
		<div id="<?php echo $entry->id; ?>" class="doc">
			<div><span>Name: </span><?php echo $entry->name; ?></div>
			<div><span>Created: </span><?php echo date('Y-m-d H:i:s', $entry->createdAt); ?></div>
			<div><a href="#" onclick="$('#infodiv<?php echo $entry->id; ?>').toggle('fast');" >More...</a><div style="display:none;overflow:hidden;" id="infodiv<?php echo $entry->id; ?>"><pre><?php echo print_r($entry, true); ?></pre></div></div>
		</div>
	<? endforeach; ?>
	</div>
	<div class="pager">
	<?php
	$page = 1;
	while($page)
	{
		$filename = pathinfo(__FILE__, PATHINFO_FILENAME).'.'.pathinfo(__FILE__, PATHINFO_EXTENSION);
		if($page == $kalturaPager->pageIndex)
			echo $page.' ';
		else
			if (isset($_GET['entryType']))
				echo '<a href="'.$filename.'?p='.$page.'&entryType='.$_GET['entryType'].'">'.$page.'</a> ';
			else
				echo '<a href="'.$filename.'?p='.$page.'">'.$page.'</a> ';
			
		if($page*$kalturaPager->pageSize > $result->totalCount)
			break;
		$page++;
	}
	?>
	</div>
</body>
</html>
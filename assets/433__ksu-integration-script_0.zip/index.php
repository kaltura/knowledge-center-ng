<?php
	//include external scripts and define constants 
	require_once("kaltura_client_v3/KalturaClient.php"); 
	
	//define constants
	define("KALTURA_PARTNER_ID", "");
	define("KALTURA_PARTNER_WEB_SERVICE_SECRET", "");

	//define session variables
	$partnerUserID          = $iCustomerId;

	//Construction of Kaltura objects for session initiation
	$config           = new KalturaConfiguration(KALTURA_PARTNER_ID);
	$client           = new KalturaClient($config);
	$ks               = $client->session->start(KALTURA_PARTNER_WEB_SERVICE_SECRET, $partnerUserID, KalturaSessionType::USER);

	$flashVars = array();
	$flashVars["uid"]   = $partnerUserID; 
	$flashVars["partnerId"] 		        = KALTURA_PARTNER_ID;
	$flashVars["subPId"] 		        = KALTURA_PARTNER_ID*100;
	$flashVars["entryId"] 	 = -1;	     
	$flashVars["ks"]   = $ks; 
	$flashVars["conversionProfile"]   = 5; 
	$flashVars["maxFileSize"]   = 200; 
	$flashVars["maxTotalSize"]   = 5000; 
	$flashVars["uiConfId"]   = (isset($_GET['uiconf']))? $_GET['uiconf']: 1103;
	$flashVars["jsDelegate"]   = "delegate"; 
?>
<html>
<head>
	<script type="text/javascript">
	var flashObj;
	var delegate = {};
	var mediaTypeInput;
	
	//KSU handlers
	delegate.readyHandler = function()
	{	
		flashObj = document.getElementById("uploader");
	}

	delegate.selectHandler = function()
	{	
		flashObj.upload();
		console.log("selectHandler()");		
		console.log(flashObj.getTotalSize());
	}

	function setMediaType()
	{
		var mediaType = document.getElementById("mediaTypeInput").value; alert(mediaType);
		console.log(mediaType);
		flashObj.setMediaType(mediaType);
	}
	
	delegate.singleUploadCompleteHandler = function(args)
	{
		
		flashObj.addEntries();
		console.log("singleUploadCompleteHandler", args[0].title);
		
	}

	delegate.allUploadsCompleteHandler = function()
	{
		console.log("allUploadsCompleteHandler");
	}

	delegate.entriesAddedHandler = function(entries)
	{
		alert(entries.length);  var entry = entries[0];alert(entry.entryId);
		document.getElementById('entryid').value = entry.entryId
		console.log(entries);
	}

	delegate.progressHandler = function(args)
	{	
		document.getElementById('progress').value = args[2].title + ": " + args[0] + " / " + args[1];
		console.log(args[2].title + ": " + args[0] + " / " + args[1]);
	}

	delegate.uiConfErrorHandler = function()
	{
		console.log("ui conf loading error");
	}

	<!--- JavaScript callback methods to activate Kaltura services via the KSU widget.-->
	function upload()
	{
		flashObj.upload();
		flashObj.addEntries();
	}

	
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js"></script>

<style>object, embed{ position:absolute; top:0; left:0; z-index:999;}</style>
</head>
<body>
<form>
			
		</form>
		<div id="uploader"> 
		</div>
		<script language="JavaScript" type="text/javascript">
			var params = {
				allowScriptAccess: "always",
				allowNetworking: "all",
				wmode: "transparent",
			};
			var attributes  = {
				id: "uploader",
				name: "uploader",
				style: "margin-left:6px;margin-top:16px;"
			};
			// set flashVar object
			var flashVars = <?php echo json_encode($flashVars); ?>;
			 <!--embed flash object-->
			swfobject.embedSWF("http://www.kaltura.com/kupload/ui_conf_id/<?php echo $flashVars["uiConfId"]; ?>", "uploader", "200", "30", "9.0.0", "expressInstall.swf", flashVars, params,attributes);

			
		</script>
		
		<div id="userInput">
		<form>
			<input type="button" style="margin:0;padding:0;" value="Step 1 - Browse & Select">
		</form>
		</div>
		<input type="text" id="entryid"/>
		<input type="text" id="progress">
			Select media type:
		 <select id="mediaTypeInput" onchange="setMediaType();">
			<option value="video">Video</option>
			<option value="image">Image</option>
			<option value="audio">Audio</option>
			<option value="media">Media</option>
			<option value="documents">Documents</option>
			<option value="swfdocuments">SWF files</option>
			<option value="Any">Any</option>
		 </select>
</body>
</html>
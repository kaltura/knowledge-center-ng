<?php
$entryId = '1_2v0u9xr2';
require_once('kalturaLib/KalturaClient.php');
$config = new KalturaConfiguration();
$config->serviceUrl = 'http://www.kaltura.com'; 
$config->partnerId = 309;
$client = new KalturaClient($config);
$email = 'zohar.babin@kaltura.com'; 
$password = '123ewqasdcxz!';
$AdminKs = $client->user->loginByLoginId($email, $password, 309);
$client->setKs($AdminKs);
$filter = new KalturaCuePointFilter();
$filter->entryIdEqual = $entryId;
$results = $client->cuePoint->listAction($filter, $pager);
$cuePoints = $results->objects;
usort($cuePoints, "cmp");

function cmp($a, $b) {
   if ($a->startTime == $b->startTime)
       return 0;
   else
      return ($a->startTime < $b->startTime ? -1 : 1);
}

function formatTime($secs) {
   $times = array(3600, 60, 1);
   $time = '';
   $tmp = '';
   for($i = 0; $i < 3; $i++) {
      $tmp = floor($secs / $times[$i]);
      if($tmp < 1) {
         $tmp = '00';
      }
      elseif($tmp < 10) {
         $tmp = '0' . $tmp;
      }
      $time .= $tmp;
      if($i < 2) {
         $time .= ':';
      }
      $secs = $secs % $times[$i];
   }
   return $time;
}

?>
<!DOCTYPE html>
<html>
  <head>
    <title></title>
	<link href="style.css" rel="stylesheet" type="text/css">
	<script src="http://html5.kaltura.org/js"></script>
	<script>
		// force HTML5
		//mw.setConfig( 'forceMobileHTML5', true );
		var myPlayer = null;
	
		// Bind to cuePointReached event
		var jsCallbackReady = function( playerId ) {
			myPlayer = document.getElementById(playerId);
			myPlayer.addJsListener("cuePointReached", "cuePointHandler");
			myPlayer.addJsListener("adOpportunity", "cuePointHandler");
		};
		
		var currentCue = null;
		var cuePointHandler = function( qPoint ) {
			switchActiveCue('cp'+qPoint.cuePoint.id);
		};
		
		var switchActiveCue = function ( newId ) {
			if (currentCue != null) currentCue.className = '';
			currentCue = document.getElementById(newId);
			currentCue.className = 'selected';
			console.log(newId);
		}
		
		var jumpToTime = function ( timesec ) {
			if (myPlayer != null) {
				myPlayer.sendNotification("doPlay");
				myPlayer.sendNotification("doSeek", timesec/1000);
			}
		}
		
	</script>
  </head>
  <body>
	<div id="wrapper" style="width:1000px;">
		<object id="kdp" name="kdp" style="float:left;" type="application/x-shockwave-flash" allowfullscreen="true" allownetworking="all" allowscriptaccess="always" height="333" width="400" bgcolor="#000000" xmlns:dc="http://purl.org/dc/terms/"
		xmlns:media="http://search.yahoo.com/searchmonkey/media/" rel="media:video" resource="http://www.kaltura.com/index.php/kwidget/cache_st/765234/wid/_309/uiconf_id/6211452/entry_id/<?php echo $entryId?>" data="http://www.kaltura.com/index.php/kwidget/cache_st/765234/wid/_309/uiconf_id/6211452/entry_id/<?php echo $entryId;?>">
		<param name="allowFullScreen" value="true" />
		  <param name="allowNetworking" value="all" />
		  <param name="allowScriptAccess" value="always" />
		  <param name="bgcolor" value="#000000" />
		  <param name="flashVars" value="getCuePointsData=true&externalInterfaceDisabled=false&autoPlay=false" />
		  <param name="movie" value="http://www.kaltura.com/index.php/kwidget/cache_st/765234/wid/_309/uiconf_id/6211452/entry_id/<?php echo $entryId;?>" />
		</object>
		<div style="width:500px;float:left;margin-left:20px;">
			<h1>Video Chapters</h1>
			<ul>
				<?php foreach ($cuePoints as $cp) : ?>
					<li><a id="<?php echo 'cp'.$cp->id; ?>" href="#" onclick="jumpToTime(<?php echo $cp->startTime; ?>);switchActiveCue('<?php echo 'cp'.$cp->id; ?>');return false;"><?php echo '['.formatTime($cp->startTime/1000).'] : ' . ((get_class($cp) == "KalturaAdCuePoint" ) ? $cp->title : $cp->code); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
  </body>
</html>
